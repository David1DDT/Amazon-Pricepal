to get the price, just run 
<code>get_amazon_price</code>